mono ../Tools/NAnt/NAnt.exe $*
